import 'dart:ui';

class Strings {

  static const String assetsUrl = 'https://www.orinell.co.za/assets/services/';
  static const String cloudFunctionsUrl = 'https://us-central1-medicnest-jaspa.cloudfunctions.net/';
}